const gameContainer = document.getElementById("game");
const endGameBtn = document.getElementById("endGame");
let cells = [];
let clickedIndices = [];

// Создание поля 5x5
for (let i = 0; i < 25; i++) {
  const cell = document.createElement("div");
  cell.classList.add("cell");
  cell.dataset.index = i;
  cell.addEventListener("click", () => {
    if (!cell.classList.contains("clicked")) {
      cell.classList.add("clicked");
      clickedIndices.push(i);
    }
  });
  gameContainer.appendChild(cell);
  cells.push(cell);
}

// Когда пользователь нажимает "Закончить", показать мины там, где не кликал
endGameBtn.addEventListener("click", () => {
  for (let i = 0; i < 25; i++) {
    if (!clickedIndices.includes(i)) {
      cells[i].classList.add("mine");
    }
  }
});
